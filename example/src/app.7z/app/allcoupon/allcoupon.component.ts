import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allcoupon',
  templateUrl: './allcoupon.component.html',
  styleUrls: ['./allcoupon.component.css']
})
export class AllcouponComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
