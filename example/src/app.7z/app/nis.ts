export class nis
{
    cost:number;
    discraption:string;
    img:string;
    item:string;
    costbsdno:number;
}