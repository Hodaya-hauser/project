import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daydeal',
  templateUrl: './daydeal.component.html',
  styleUrls: ['./daydeal.component.css']
})
export class DaydealComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
