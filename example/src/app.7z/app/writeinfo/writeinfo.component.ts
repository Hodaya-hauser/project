import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-writeinfo',
  templateUrl: './writeinfo.component.html',
  styleUrls: ['./writeinfo.component.css']
})
export class WriteinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
