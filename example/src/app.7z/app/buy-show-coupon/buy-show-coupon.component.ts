import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-show-coupon',
  templateUrl: './buy-show-coupon.component.html',
  styleUrls: ['./buy-show-coupon.component.css']
})
export class BuyShowCouponComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
