import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chtinfo',
  templateUrl: './chtinfo.component.html',
  styleUrls: ['./chtinfo.component.css']
})
export class ChtinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
