import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-besadnoinfo',
  templateUrl: './besadnoinfo.component.html',
  styleUrls: ['./besadnoinfo.component.css']
})
export class BesadnoinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
